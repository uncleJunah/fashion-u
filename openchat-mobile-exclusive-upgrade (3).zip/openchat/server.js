const express=require('express'),crypto=require('crypto'),Database=require('better-sqlite3');
const {AsyncLocalStorage}=require('async_hooks');require('fs').mkdirSync('biz',{recursive:true});
const E=process.env,als=new AsyncLocalStorage(),M=new Database(E.MASTER_DB||'master.db'),pool=new Map();
M.exec('create table if not exists businesses(id integer primary key,name text,key text unique,created integer);create table if not exists logins(email text primary key,biz int);create table if not exists kv(k text primary key,v text)');
// ---- Web Push keys (generated once, kept in master.db; env values win). Losing master.db means devices must re-enable alerts.
const push=require('./push'),VAPID=(()=>{if(E.VAPID_PUBLIC_KEY&&E.VAPID_PRIVATE_KEY)return{publicKey:E.VAPID_PUBLIC_KEY,privateKey:E.VAPID_PRIVATE_KEY};
 const s=M.prepare("select v from kv where k='vapid'").get();if(s)return JSON.parse(s.v);const v=push.generateVapid();M.prepare("insert into kv values('vapid',?)").run(JSON.stringify(v));return v})();
const VAPID_SUBJECT=E.VAPID_SUBJECT||'mailto:admin@example.com',PUSH_HOSTS=(E.PUSH_ALLOWED_HOSTS||'').split(',').map(s=>s.trim()).filter(Boolean);
const SCHEMA=`create table if not exists users(id integer primary key,email text unique,name text,pass text,role text default 'agent',phone text,last_in integer default 0);
create table if not exists contacts(id integer primary key,phone text unique,name text default '',labels text default '',opted_in int default 0,opted_out int default 0,consent_source text,consent_at text,bot int default 1,last_in integer default 0,last_msg text default '',assigned int,status text default 'open',attrs text default '{}',unread int default 0);
create table if not exists messages(id integer primary key,contact_id int,dir text,body text,wa_id text,status text default 'sent',ts integer,user_id int,media text,media_state int default 0);
create table if not exists automations(id integer primary key,keyword text,reply text);
create table if not exists campaigns(id integer primary key,name text,template text,lang text,status text default 'running',sent int default 0,failed int default 0,total int default 0,created integer,vars text,start_at integer default 0);
create table if not exists queue(id integer primary key,campaign_id int,contact_id int,done int default 0);
create table if not exists products(id integer primary key,name text,price text,descr text);
create table if not exists settings(k text primary key,v text);
create table if not exists invites(token text primary key,role text,created integer);
create table if not exists notifs(wa_id text primary key,contact_id int,user_id int);
create table if not exists orders(id integer primary key,ext_id text,summary text,created integer);
create table if not exists canned(id integer primary key,title text,text text);
create table if not exists push_subs(endpoint text primary key,user_id int,p256dh text,auth text,ua text,vib int default 1,created integer);
create table if not exists push_jobs(id integer primary key,endpoint text,payload text,created integer,next_at integer,tries int default 0,done int default 0);
create table if not exists wh_events(id integer primary key,body text,created integer,done int default 0,attempts int default 0);`;
// Upgrades for databases created by older versions
function migrate(d){for(const c of['media text','media_state int default 0'])if(!d.prepare('pragma table_info(messages)').all().some(x=>x.name===c.split(' ')[0]))d.exec('alter table messages add column '+c);
 if(!d.prepare('pragma table_info(contacts)').all().some(x=>x.name==='unread'))d.exec('alter table contacts add column unread int default 0');
 try{d.exec('create unique index if not exists messages_wa_id on messages(wa_id) where wa_id is not null')}catch(e){console.error('Could not add unique index on messages.wa_id (duplicate rows exist):',e.message)}
 d.exec('create index if not exists push_jobs_due on push_jobs(done,next_at);create index if not exists wh_events_due on wh_events(done,id)')}
const open=id=>{let d=pool.get(id);if(!d){d=new Database('biz/'+id+'.db');d.pragma('journal_mode=WAL');d.pragma('synchronous=FULL');d.exec(SCHEMA);migrate(d);pool.set(id,d)}return d};
const db={prepare:s=>als.getStore().db.prepare(s),exec:s=>als.getStore().db.exec(s),transaction:f=>als.getStore().db.transaction(f)};
const bizKey=(q,r,n)=>{const b=M.prepare('select * from businesses where key=?').get(q.params.key);if(!b)return r.sendStatus(404);q.bid=b.id;als.run({db:open(b.id),bid:b.id},()=>n())};
const app=express(),SECRET=E.SESSION_SECRET||crypto.randomBytes(32).toString('hex');
app.set('trust proxy',1);app.use(express.json({verify:(q,_,b)=>q.raw=b}));app.use(express.static('public'));
const hash=(p,s=crypto.randomBytes(16).toString('hex'))=>s+':'+crypto.scryptSync(p,s,32).toString('hex');
const check=(p,h)=>{const a=Buffer.from(hash(p,h.split(':')[0])),b=Buffer.from(h);return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const sign=v=>v+'.'+crypto.createHmac('sha256',SECRET).update(v).digest('hex');
const get=(s,...a)=>db.prepare(s).get(...a),all=(s,...a)=>db.prepare(s).all(...a),run=(s,...a)=>db.prepare(s).run(...a);
const cfg=k=>get('select v from settings where k=?',k)?.v||'';
const phone=p=>{let d=String(p||'').replace(/\D/g,'');if(d.startsWith('00'))d=d.slice(2);const cc=cfg('DEFAULT_CC').replace(/\D/g,'');if(cc&&d.startsWith('0'))d=cc+d.slice(1);return d};
async function wa(body){if(!cfg('WA_PHONE_ID')||!cfg('WA_TOKEN'))throw new Error('WhatsApp is not connected yet. Add your credentials in the Setup tab.');const r=await fetch(`https://graph.facebook.com/v21.0/${cfg('WA_PHONE_ID')}/messages`,{method:'POST',headers:{Authorization:'Bearer '+cfg('WA_TOKEN'),'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',...body})});const j=await r.json();if(!r.ok)throw new Error(j.error?.message||'Send failed');return j.messages?.[0]?.id}
const log=(cid,dir,body,wid,uid)=>run('insert into messages(contact_id,dir,body,wa_id,ts,user_id) values(?,?,?,?,?,?)',cid,dir,body,wid,Date.now(),uid||null);
async function reply(c,t,uid){try{const id=await wa({to:c.phone,type:'text',text:{body:t}});log(c.id,'out',t,id,uid);run('update contacts set last_msg=? where id=?',t,c.id)}catch(e){console.error(e.message)}}

// ---- Team on WhatsApp: customer messages go to every teammate's WhatsApp; first to read or reply takes the chat
// Atomic conversation ownership: only one employee can claim an unassigned chat.
const claim=(cid,uid)=>run('update contacts set assigned=?,bot=0 where id=? and assigned is null',uid,cid).changes>0;
const ownsOrClaim=(cid,uid)=>db.transaction(()=> {
 const c=get('select assigned from contacts where id=?',cid);
 if(!c)return {missing:true};
 if(c.assigned&&c.assigned!==uid)return {owned:false,assigned:c.assigned};
 if(!c.assigned)run('update contacts set assigned=?,bot=0 where id=? and assigned is null',uid,cid);
 const latest=get('select assigned from contacts where id=?',cid);
 return latest?.assigned===uid?{owned:true}:{owned:false,assigned:latest?.assigned};
}).immediate();
const tell=async(u,t)=>{try{await wa({to:u.phone,type:'text',text:{body:t}})}catch(e){console.error(e.message)}};
async function alertUser(u,c,text,pre=''){if(cfg('ALERT_MODE')!=='whatsapp')return;const who=(c.name||'+'+c.phone).slice(0,60);try{let id;
if(Date.now()-u.last_in<864e5)id=await wa({to:u.phone,type:'text',text:{body:(pre+who+': '+text).slice(0,900)+'\n\nReply to this message to answer the customer.'}});
else if(cfg('NOTIFY_TEMPLATE'))id=await wa({to:u.phone,type:'template',template:{name:cfg('NOTIFY_TEMPLATE'),language:{code:cfg('NOTIFY_LANG')||'en'},components:[{type:'body',parameters:[{type:'text',text:who},{type:'text',text:(pre+text).replace(/\s+/g,' ').slice(0,300)}]}]}});
if(id)run('insert into notifs values(?,?,?)',id,c.id,u.id)}catch(e){console.error(e.message)}}
async function notify(c,text){for(const u of all("select * from users where phone is not null and phone!=''").filter(u=>!c.assigned||u.id===c.assigned))await alertUser(u,c,text)}
async function staffMsg(u,m){const n=m.context?.id&&get('select * from notifs where wa_id=?',m.context.id);
if(!n)return tell(u,'To answer a customer, press and hold their message here and tap Reply.');
const c=get('select * from contacts where id=?',n.contact_id);
if(!m.text?.body)return tell(u,'Only text replies are supported for now.');
const lock=ownsOrClaim(c.id,u.id);
if(!lock.owned)return tell(u,(get('select name from users where id=?',lock.assigned)?.name||'A teammate')+' is already handling this chat.');
if(Date.now()-c.last_in>864e5)return tell(u,'The 24-hour window with this customer is closed. Send a template from the web inbox.');
await reply(c,m.text.body,u.id)}
// ---- Background push: who gets alerted, and the durable queue behind it
// Unassigned chat: every teammate. Assigned chat: its owner plus administrators (switch off in Setup with PUSH_ADMINS=off).
function pushUsers(c){const us=all('select id,role from users');if(!c.assigned)return us.map(u=>u.id);const adm=cfg('PUSH_ADMINS')!=='off';return us.filter(u=>u.id===c.assigned||(adm&&u.role==='admin')).map(u=>u.id)}
// One job per device, written to disk. Safe to call inside a transaction. The worker below delivers and retries.
function enqueuePush(uids,p){if(!uids.length)return 0;const subs=all(`select endpoint,vib from push_subs where user_id in (${uids.map(()=>'?').join()})`,...uids),now=Date.now();
for(const s of subs)run('insert into push_jobs(endpoint,payload,created,next_at) values(?,?,?,?)',s.endpoint,JSON.stringify({...p,vib:s.vib}),now,now);return subs.length}
function pushChat(c,text){enqueuePush(pushUsers(c),{kind:'msg',title:(c.name||'+'+c.phone).slice(0,60),body:cfg('PUSH_PREVIEW')==='off'?'New WhatsApp message':String(text).replace(/\s+/g,' ').slice(0,140),tag:'chat-'+c.id,cid:c.id,url:'/?chat='+c.id})}
const PUSH_RETRY=[5e3,3e4,12e4,6e5,18e5,36e5];
async function pushTick(){const jobs=all('select * from push_jobs where done=0 and next_at<=? order by id limit 25',Date.now());
await Promise.all(jobs.map(async j=>{const s=get('select * from push_subs where endpoint=?',j.endpoint);
 if(!s||Date.now()-j.created>864e5||!push.endpointAllowed(s.endpoint,PUSH_HOSTS))return run('update push_jobs set done=1 where id=?',j.id);
 let r;try{r=await push.send(s,j.payload,{vapid:VAPID,subject:VAPID_SUBJECT})}catch(e){r={status:0,error:e.message}}
 if(r.status>=200&&r.status<300)return run('update push_jobs set done=1 where id=?',j.id);
 if(r.status===404||r.status===410){run('delete from push_subs where endpoint=?',j.endpoint);return run('update push_jobs set done=1 where id=?',j.id)}
 if((r.status===0||r.status===429||r.status>=500)&&j.tries<PUSH_RETRY.length)return run('update push_jobs set tries=tries+1,next_at=? where id=?',Date.now()+PUSH_RETRY[j.tries],j.id);
 console.error('Push refused for one device:',r.status,r.error||'');run('update push_jobs set done=1 where id=?',j.id)}))}
// ---- WhatsApp webhook (signature verified)
app.get('/webhook/:key',bizKey,(q,r)=>q.query['hub.verify_token']===cfg('VERIFY_TOKEN')?r.send(q.query['hub.challenge']):r.sendStatus(403));
// Every verified webhook call is written to disk (wh_events) BEFORE we answer 200, so a crash or restart cannot lose it.
// Anything not fully processed is replayed automatically; Meta also re-sends if we ever answer with an error.
const inflight=new Set();
app.post('/webhook/:key',bizKey,(q,r)=>{const sig=q.headers['x-hub-signature-256']||'',ok='sha256='+crypto.createHmac('sha256',cfg('APP_SECRET')||'x').update(q.raw||'').digest('hex');
if(sig.length!==ok.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(ok)))return r.sendStatus(401);
let id;try{id=run('insert into wh_events(body,created) values(?,?)',q.raw.toString('utf8'),Date.now()).lastInsertRowid}catch(e){console.error('Could not store webhook event:',e.message);return r.sendStatus(500)}
r.sendStatus(200);processEvent(+id)});
async function processEvent(id){const key=als.getStore().bid+':'+id;if(inflight.has(key))return;const ev=get('select * from wh_events where id=? and done=0',id);if(!ev)return;inflight.add(key);
try{await ingest(JSON.parse(ev.body));run('update wh_events set done=1 where id=?',id)}
catch(e){console.error('Webhook event',id,'failed (will retry):',e.message);run('update wh_events set attempts=attempts+1 where id=?',id)}finally{inflight.delete(key)}}
const msgText=m=>{if(m.text?.body)return m.text.body;const x=m[m.type]||{},cap=x.caption?' '+x.caption:'',L={audio:x.voice?'🎤 Voice note':'🎵 Audio',image:'📷 Photo',video:'🎥 Video',document:'📄 '+(x.filename||'Document'),sticker:'🙂 Sticker'}[m.type];return m.button?.text||m.interactive?.button_reply?.title||m.interactive?.list_reply?.title||(L?L+cap:'['+m.type+']')};
const mediaOf=m=>{const x=['audio','image','video','document','sticker'].includes(m.type)&&m[m.type];return x&&x.id?{id:String(x.id),type:m.type,mime:x.mime_type||'',voice:!!x.voice,name:x.filename||'',caption:x.caption||''}:null};
async function ingest(body){for(const en of body.entry||[])for(const ch of en.changes||[]){const v=ch.value||{};
for(const s of v.statuses||[]){run('update messages set status=? where wa_id=?',s.status,s.id);if(s.status==='read'){const n=get('select * from notifs where wa_id=?',s.id);if(n)claim(n.contact_id,n.user_id)}}
for(const m of v.messages||[]){if(get('select 1 x from messages where wa_id=?',m.id))continue;const sf=get('select * from users where phone=?',phone(m.from));if(sf){run('update users set last_in=? where id=?',Date.now(),sf.id);log(0,'staff',m.text?.body||'',m.id);await staffMsg(sf,m);continue}
const t=msgText(m),isNew=!get('select 1 x from contacts where phone=?',m.from);
// The message, the unread counter and the push jobs are saved in ONE transaction: all of it exists, or none of it does.
const cid=db.transaction(()=>{if(get('select 1 x from messages where wa_id=?',m.id))return 0;
 run(`insert into contacts(phone,name) values(?,?) on conflict(phone) do update set name=coalesce(nullif(name,''),excluded.name)`,m.from,v.contacts?.[0]?.profile?.name||'');
 const c=get('select * from contacts where phone=?',m.from);log(c.id,'in',t,m.id);const md=mediaOf(m);if(md)run('update messages set media=?,media_state=1 where wa_id=?',JSON.stringify(md),m.id);
 run("update contacts set last_in=?,last_msg=?,status='open',unread=unread+1 where id=?",Date.now(),t,c.id);
 pushChat(get('select * from contacts where id=?',c.id),t);return c.id}).immediate();
if(!cid)continue;const c=get('select * from contacts where id=?',cid);await notify(c,t);await handle(c,t.trim(),isNew,!!mediaOf(m))}}}
async function handle(c,t,isNew,isMedia){if(c.assigned)return;const k=t.toLowerCase();
if(['stop','unsubscribe','cancel'].includes(k)){run('update contacts set opted_out=1 where id=?',c.id);return reply(c,'You are unsubscribed and will get no more campaigns. Reply START to subscribe again.')}
if(['start','subscribe'].includes(k)){run("update contacts set opted_in=1,opted_out=0,consent_source='customer replied START',consent_at=? where id=?",new Date().toISOString(),c.id);return reply(c,'You are subscribed. Reply STOP any time to opt out.')}
if(isNew&&cfg('WELCOME_MSG'))return reply(c,cfg('WELCOME_MSG'));
{const f=cfg('HOURS_FROM'),to=cfg('HOURS_TO'),hr=(new Date().getUTCHours()+(+cfg('TZ_OFFSET')||0)+24)%24;
if(cfg('AWAY_MSG')&&f!==''&&to!==''&&(hr<+f||hr>=+to)){if(!get("select 1 x from messages where contact_id=? and dir='out' and body=? and ts>?",c.id,cfg('AWAY_MSG'),Date.now()-216e5))return reply(c,cfg('AWAY_MSG'));}}
const a=all('select * from automations').find(a=>k.includes(a.keyword.toLowerCase()));
if(a)return reply(c,a.reply);if(cfg('ANTHROPIC_API_KEY')&&c.bot&&!isMedia)return reply(c,await ai(c))}
async function ai(c){const f='Thanks! A team member will reply shortly.';try{const h=all('select dir,body from messages where contact_id=? order by id desc limit 10',c.id).reverse().map(m=>({role:m.dir==='in'?'user':'assistant',content:m.body}));while(h.length&&h[0].role!=='user')h.shift();
const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'x-api-key':cfg('ANTHROPIC_API_KEY'),'anthropic-version':'2023-06-01','content-type':'application/json'},body:JSON.stringify({model:cfg('AI_MODEL')||'claude-sonnet-5-5',max_tokens:400,system:cfg('AI_PROMPT')||'You are a concise support assistant.',messages:h})});
return(await r.json()).content?.[0]?.text||f}catch{return f}}

// ---- Store orders: Shopify, WooCommerce or any JSON webhook
async function alertAll(who,text){if(cfg('ALERT_MODE')!=='whatsapp')return;for(const u of all("select * from users where phone is not null and phone!=''")){try{if(Date.now()-u.last_in<864e5)await wa({to:u.phone,type:'text',text:{body:(who+': '+text).slice(0,900)}});else if(cfg('NOTIFY_TEMPLATE'))await wa({to:u.phone,type:'template',template:{name:cfg('NOTIFY_TEMPLATE'),language:{code:cfg('NOTIFY_LANG')||'en'},components:[{type:'body',parameters:[{type:'text',text:who},{type:'text',text:text.replace(/\s+/g,' ').slice(0,300)}]}]}})}catch(e){console.error(e.message)}}}
app.post('/hook/order/:key',bizKey,async(q,r)=>{const b=q.body||{},h=q.headers,sec=cfg('ORDER_SECRET');
if(sec&&(h['x-shopify-hmac-sha256']||h['x-wc-webhook-signature']||'')!==crypto.createHmac('sha256',sec).update(q.raw||'').digest('base64'))return r.sendStatus(401);
const cu=b.customer||b.billing||{},nm=(cu.first_name?cu.first_name+' '+(cu.last_name||''):b.customer_name||'Customer').trim(),ph=phone(b.phone||cu.phone||b.billing_address?.phone||b.customer_phone),
items=(b.line_items||b.items||[]).map(i=>(i.quantity||i.qty||1)+' x '+(i.title||i.name)).join(', '),id=b.name||b.order_number||b.number||b.id||b.order_id,total=[b.total_price||b.total,b.currency].filter(Boolean).join(' ');
if(!id&&!items)return r.sendStatus(200);if(id&&get('select 1 x from orders where ext_id=?',String(id)))return r.sendStatus(200);
const txt=`Order ${id||''}: ${items||'items'}${total?', total '+total:''}. ${nm}${ph?' +'+ph:''}`;run('insert into orders(ext_id,summary,created) values(?,?,?)',String(id||''),txt,Date.now());
if(ph.length>=8){run('insert into contacts(phone,name) values(?,?) on conflict(phone) do nothing',ph,nm);const c=get('select * from contacts where phone=?',ph);log(c.id,'note','[order] '+txt);run('update contacts set last_msg=? where id=?','[order] '+(id||''),c.id)}
r.sendStatus(200);enqueuePush(all('select id from users').map(u=>u.id),{kind:'order',title:'New order',body:cfg('PUSH_PREVIEW')==='off'?'A new order arrived':txt.slice(0,140),tag:'order-'+(id||Date.now()),url:'/?tab=orders'});await alertAll('New order',txt)});
// ---- Public opt-in form (/join)
const hits={};app.post('/join/:key',bizKey,(q,r)=>{const now=Date.now();hits[q.ip]=(hits[q.ip]||[]).filter(t=>now-t<36e5);if(hits[q.ip].length>=10)return r.status(429).json({error:'Too many tries. Try again later.'});hits[q.ip].push(now);
const{phone:p,name,consent}=q.body||{},n=phone(p);if(n.length<8||!consent)return r.status(400).json({error:'Enter a valid number and tick the consent box.'});
run(`insert into contacts(phone,name,opted_in,opted_out,consent_source,consent_at) values(?,?,1,0,'web form',?) on conflict(phone) do update set opted_in=1,opted_out=0,consent_source='web form',consent_at=excluded.consent_at`,n,String(name||'').slice(0,80),new Date().toISOString());r.json({ok:1})});
app.post('/invite/accept',(q,r,n)=>{const id=+String(q.body?.token).split('.')[0];if(!M.prepare('select 1 x from businesses where id=?').get(id))return r.status(400).json({error:'This invite link has expired. Ask your admin for a new one.'});als.run({db:open(id),bid:id},()=>n())},(q,r)=>{const{token,name,email,password,phone:ph}=q.body||{},i=get('select * from invites where token=?',token);
if(!i||Date.now()-i.created>6048e5)return r.status(400).json({error:'This invite link has expired. Ask your admin for a new one.'});
if(!name||!email||!password||password.length<8)return r.status(400).json({error:'Fill every field. The password needs 8 or more characters.'});
try{M.prepare('insert into logins values(?,?)').run(email.toLowerCase(),als.getStore().bid);run('insert into users(email,name,pass,role,phone) values(?,?,?,?,?)',email,name,hash(password),i.role,phone(ph));run('delete from invites where token=?',token);r.json({ok:1})}catch{r.status(400).json({error:'That email is already registered.'})}});
// ---- Auth
const cookie=(r,v,age)=>r.setHeader('Set-Cookie','s='+v+'; HttpOnly; SameSite=Lax; Path=/; Max-Age='+age+(E.NODE_ENV==='production'?'; Secure':''));
const session=(r,b,u)=>cookie(r,sign(b+'.'+u+'.'+(Date.now()+6048e5)),604800);
app.post('/api/login',(q,r)=>{const{email,password}=q.body||{},em=String(email||'').toLowerCase(),l=M.prepare('select biz from logins where email=?').get(em);
if(!l||!password)return r.status(401).json({error:'Wrong email or password'});
als.run({db:open(l.biz)},()=>{const u=get('select * from users where lower(email)=?',em);if(!u||!check(password,u.pass))return r.status(401).json({error:'Wrong email or password'});session(r,l.biz,u.id);r.json({ok:1})})});
app.post('/api/register',async(q,r)=>{const{business,name,email,password,phone:ph,WA_PHONE_ID,WA_TOKEN,APP_SECRET,VERIFY_TOKEN,ANTHROPIC_API_KEY}=q.body||{};
if(!business||!name||!email||!password||password.length<8)return r.status(400).json({error:'Fill every field. The password needs 8 or more characters.'});
const em=email.toLowerCase();if(M.prepare('select 1 x from logins where email=?').get(em))return r.status(400).json({error:'That email is already registered.'});
if((WA_PHONE_ID||WA_TOKEN)&&!(WA_PHONE_ID&&WA_TOKEN))return r.status(400).json({error:'Enter both the Phone Number ID and the access token, or leave both empty.'});
if(WA_PHONE_ID){try{const x=await fetch('https://graph.facebook.com/v21.0/'+encodeURIComponent(String(WA_PHONE_ID).trim())+'?fields=display_phone_number',{headers:{Authorization:'Bearer '+String(WA_TOKEN).trim()}});if(!x.ok)return r.status(400).json({error:'Meta rejected these credentials: '+((await x.json()).error?.message||'check the Phone Number ID and token')})}catch{return r.status(400).json({error:'Could not reach Meta to check the credentials. Try again.'})}}
const key=crypto.randomBytes(12).toString('hex'),id=M.prepare('insert into businesses(name,key,created) values(?,?,?)').run(String(business).slice(0,80),key,Date.now()).lastInsertRowid;M.prepare('insert into logins values(?,?)').run(em,id);
als.run({db:open(id)},()=>{const u=run('insert into users(email,name,pass,role,phone) values(?,?,?,?,?)',em,name,hash(password),'admin',phone(ph)).lastInsertRowid;const vt=String(VERIFY_TOKEN||'').trim()||crypto.randomBytes(8).toString('hex');for(const[k,v]of Object.entries({WA_PHONE_ID,WA_TOKEN,APP_SECRET,VERIFY_TOKEN:vt,ANTHROPIC_API_KEY}))if(v)run('insert into settings(k,v) values(?,?)',k,String(v).trim());
session(r,id,u);r.json({ok:1,key,verify:vt})})});
app.post('/api/logout',(q,r)=>{cookie(r,'',0);r.json({ok:1})});
app.use('/api',(q,r,n)=>{const c=(q.headers.cookie||'').match(/s=([^;]+)/);if(c){const[b,id,exp]=c[1].split('.');if(sign(b+'.'+id+'.'+exp)===c[1]&&+exp>Date.now()&&M.prepare('select 1 x from businesses where id=?').get(b))return als.run({db:open(+b),bid:+b},()=>{q.user=get('select * from users where id=?',id);q.bid=+b;q.user?n():r.status(401).json({error:'Sign in'})})}r.status(401).json({error:'Sign in'})});
const admin=(q,r,n)=>q.user.role==='admin'?n():r.status(403).json({error:'Admins only'});
app.get('/api/me',(q,r)=>r.json({id:q.user.id,name:q.user.name,role:q.user.role,biz:M.prepare('select name,key from businesses where id=?').get(q.bid)}));
app.get('/healthz',(q,r)=>r.json({ok:1,uptime:Math.round(process.uptime())}));
app.get('/api/push/key',(q,r)=>r.json({key:VAPID.publicKey,devices:get('select count(*) n from push_subs where user_id=?',q.user.id).n}));
app.post('/api/push/subscribe',(q,r)=>{const s=q.body?.subscription||{},k=s.keys||{};
if(!push.endpointAllowed(s.endpoint,PUSH_HOSTS)||push.unb64u(k.p256dh||'').length!==65||push.unb64u(k.auth||'').length!==16)return r.status(400).json({error:'This browser sent an invalid push subscription.'});
run('insert into push_subs(endpoint,user_id,p256dh,auth,ua,vib,created) values(?,?,?,?,?,?,?) on conflict(endpoint) do update set user_id=excluded.user_id,p256dh=excluded.p256dh,auth=excluded.auth,ua=excluded.ua,vib=excluded.vib',s.endpoint,q.user.id,k.p256dh,k.auth,String(q.headers['user-agent']||'').slice(0,200),q.body.vibrate===false?0:1,Date.now());r.json({ok:1})});
app.post('/api/push/unsubscribe',(q,r)=>{run('delete from push_subs where endpoint=? and user_id=?',String(q.body?.endpoint||''),q.user.id);r.json({ok:1})});
app.post('/api/push/test',async(q,r)=>{const subs=all('select * from push_subs where user_id=?',q.user.id);if(!subs.length)return r.status(409).json({error:'No device of yours is registered for alerts yet. Turn on alerts first.'});
const p=JSON.stringify({kind:'test',title:'OpenChat test',body:'Background alerts work on this device.',tag:'openchat-test',url:'/'}),out=[];
for(const s of subs){const x=await push.send(s,JSON.stringify({...JSON.parse(p),vib:s.vib}),{vapid:VAPID,subject:VAPID_SUBJECT});if(x.status===404||x.status===410)run('delete from push_subs where endpoint=?',s.endpoint);out.push(x.status>=200&&x.status<300?'ok':x.status===404||x.status===410?'expired':'refused ('+(x.status||x.error)+')')}
r.json({results:out})});
app.get('/api/team',(q,r)=>r.json(all('select id,name from users')));
app.post('/api/me/phone',(q,r)=>{run('update users set phone=? where id=?',phone(q.body.phone),q.user.id);r.json({ok:1})});
app.get('/api/users',admin,(q,r)=>r.json(all('select id,email,name,role,phone,(select count(*) from push_subs p where p.user_id=users.id) devices from users')));
app.post('/api/users',admin,(q,r)=>{try{const{email,name,password,role,phone:ph}=q.body;M.prepare('insert into logins values(?,?)').run(String(email).toLowerCase(),q.bid);run('insert into users(email,name,pass,role,phone) values(?,?,?,?,?)',email,name,hash(password),role==='admin'?'admin':'agent',phone(ph));r.json({ok:1})}catch(e){r.status(400).json({error:e.message})}});
app.delete('/api/users/:id',admin,(q,r)=>{if(+q.params.id!==q.user.id){const u=get('select email from users where id=?',q.params.id);if(u)M.prepare('delete from logins where email=?').run(u.email.toLowerCase());run('update contacts set assigned=null where assigned=?',q.params.id);run('delete from push_subs where user_id=?',q.params.id);run('delete from users where id=?',q.params.id)}r.json({ok:1})});

// ---- Contacts & inbox
app.get('/api/contacts',(q,r)=>{const s='%'+(q.query.q||'')+'%';r.json(all(`select c.*,u.name assignee from contacts c left join users u on u.id=c.assigned where (c.name like ? or c.phone like ?)${q.query.inbox?" and c.last_msg!=''":''} order by c.last_in desc,c.id desc limit 500`,s,s))});
app.post('/api/contacts',(q,r)=>{let n=0;for(const c of Array.isArray(q.body)?q.body:[q.body]){const p=phone(c.phone);if(p.length<8)continue;
run(`insert into contacts(phone,name,labels,opted_in,consent_source,consent_at) values(?,?,?,?,?,?) on conflict(phone) do update set name=coalesce(nullif(excluded.name,''),name),labels=excluded.labels`,p,c.name||'',c.labels||'',c.consent?1:0,c.consent?c.source||'manual':null,c.consent?new Date().toISOString():null);n++}r.json({added:n})});
app.patch('/api/contacts/:id',(q,r)=>{const{optin,source}=q.body;if(optin)run("update contacts set opted_in=1,opted_out=0,consent_source=?,consent_at=? where id=?",source||'manual',new Date().toISOString(),q.params.id);else run('update contacts set opted_out=1 where id=?',q.params.id);r.json({ok:1})});
app.get('/api/messages/:id',(q,r)=>{const c=get('select id,assigned from contacts where id=?',q.params.id);if(!c)return r.sendStatus(404);if(!c.assigned)claim(c.id,q.user.id);if(q.query.seen&&get('select assigned from contacts where id=?',c.id)?.assigned===q.user.id)run('update contacts set unread=0 where id=?',c.id);r.json(all('select m.*,u.name agent from messages m left join users u on u.id=m.user_id where m.contact_id=? order by m.id',q.params.id))});
app.post('/api/messages/:id',async(q,r)=>{const c=get('select * from contacts where id=?',q.params.id);if(!c)return r.sendStatus(404);
const text=String(q.body?.text||'').trim();if(!text)return r.status(400).json({error:'Type a message first.'});
const lock=ownsOrClaim(c.id,q.user.id);if(!lock.owned)return r.status(403).json({error:(get('select name from users where id=?',lock.assigned)?.name||'A teammate')+' is handling this chat. Only its owner or an administrator can take over.'});
if(Date.now()-c.last_in>864e5)return r.status(409).json({error:'The 24-hour reply window is closed. Send an approved template from Campaigns.'});
run('update contacts set bot=0 where id=?',c.id);
try{const id=await wa({to:c.phone,type:'text',text:{body:text}});log(c.id,'out',text,id,q.user.id);run('update contacts set last_msg=? where id=?',text,c.id);r.json({ok:1})}catch(e){r.status(502).json({error:e.message})}});

// ---- Credentials saved in-app (admin only) & invite links
const KEYS=['WA_PHONE_ID','WA_TOKEN','APP_SECRET','VERIFY_TOKEN','ANTHROPIC_API_KEY','AI_PROMPT','NOTIFY_TEMPLATE','NOTIFY_LANG','DEFAULT_CC','ORDER_SECRET','WELCOME_MSG','AWAY_MSG','HOURS_FROM','HOURS_TO','TZ_OFFSET','ALERT_MODE','PUSH_ADMINS','PUSH_PREVIEW'],HIDE=['WA_TOKEN','APP_SECRET','ANTHROPIC_API_KEY','ORDER_SECRET'];
app.get('/api/settings',admin,(q,r)=>r.json(Object.fromEntries(KEYS.map(k=>[k,HIDE.includes(k)&&cfg(k)?'••••'+cfg(k).slice(-4):cfg(k)]))));
app.post('/api/settings',admin,(q,r)=>{for(const k of KEYS){const v=String(q.body[k]??'').trim();if(v&&!v.startsWith('••••'))run('insert into settings(k,v) values(?,?) on conflict(k) do update set v=excluded.v',k,v==='-'?'':v)}r.json({ok:1})});
app.post('/api/invites',admin,(q,r)=>{const t=q.bid+'.'+crypto.randomBytes(18).toString('hex');run('insert into invites values(?,?,?)',t,q.body.role==='admin'?'admin':'agent',Date.now());r.json({token:t})});
// ---- Setup status & first-contact templates
app.get('/api/status',async(q,r)=>{const s={whatsapp:!!(cfg('WA_PHONE_ID')&&cfg('WA_TOKEN')),secret:!!cfg('APP_SECRET'),verify:!!cfg('VERIFY_TOKEN'),ai:!!cfg('ANTHROPIC_API_KEY')};
if(s.whatsapp)try{const x=await fetch(`https://graph.facebook.com/v21.0/${cfg('WA_PHONE_ID')}?fields=display_phone_number,verified_name,quality_rating`,{headers:{Authorization:'Bearer '+cfg('WA_TOKEN')}}),j=await x.json();if(x.ok)s.number=j;else s.error=j.error?.message}catch(e){s.error=e.message}
r.json(s)});
app.post('/api/messages/:id/template',async(q,r)=>{const c=get('select * from contacts where id=?',q.params.id);if(!c)return r.sendStatus(404);
const lock=ownsOrClaim(c.id,q.user.id);if(!lock.owned)return r.status(403).json({error:(get('select name from users where id=?',lock.assigned)?.name||'A teammate')+' is handling this chat. Only its owner can send a reply.'});
if(!c.opted_in||c.opted_out)return r.status(409).json({error:'This contact has not given consent to receive templates.'});
try{const id=await wa({to:c.phone,type:'template',template:{name:q.body.name,language:{code:q.body.lang||'en_US'}}});log(c.id,'out','[template] '+q.body.name,id,q.user.id);run('update contacts set last_msg=? where id=?','[template] '+q.body.name,c.id);r.json({ok:1})}catch(e){r.status(502).json({error:e.message})}});
// ---- Contact editing, notes, quick replies, dashboard
app.post('/api/contacts/:id/edit',(q,r)=>{const b=q.body,c=get('select * from contacts where id=?',q.params.id);if(!c)return r.sendStatus(404);if(b.status&&b.status!==c.status&&c.assigned&&c.assigned!==q.user.id&&q.user.role!=='admin')return r.status(403).json({error:'Only the teammate handling this chat or an administrator can change its status.'});run('update contacts set name=?,labels=?,attrs=?,status=? where id=?',b.name??c.name,b.labels??c.labels,b.attrs?JSON.stringify(b.attrs):c.attrs,b.status||c.status,c.id);r.json({ok:1})});
app.post('/api/messages/:id/note',(q,r)=>{log(+q.params.id,'note',q.body.text,null,q.user.id);r.json({ok:1})});
app.get('/api/canned',(q,r)=>r.json(all('select * from canned')));
app.post('/api/canned',(q,r)=>{run('insert into canned(title,text) values(?,?)',q.body.title,q.body.text);r.json({ok:1})});
app.delete('/api/canned/:id',(q,r)=>{run('delete from canned where id=?',q.params.id);r.json({ok:1})});
app.get('/api/dashboard',(q,r)=>{const d=Date.now()-6048e5,n=(s,...a)=>get(s,...a).n,off=Math.max(-840,Math.min(840,Math.trunc(+q.query.tz)||0))*60;r.json({daily:all("select strftime('%Y-%m-%d',ts/1000+?,'unixepoch') d,dir,count(*) n from messages where dir in('in','out') and ts>? group by d,dir",off,Date.now()-8*864e5),contacts:n('select count(*) n from contacts'),optin:n('select count(*) n from contacts where opted_in=1 and opted_out=0'),open:n("select count(*) n from contacts where status='open' and last_in>0"),unassigned:n("select count(*) n from contacts where assigned is null and status='open' and last_in>0"),in7:n("select count(*) n from messages where dir='in' and ts>?",d),out7:n("select count(*) n from messages where dir='out' and ts>?",d),agents:all("select u.name,count(c.id) chats,(select count(*) from messages m where m.user_id=u.id and m.dir='out' and m.ts>?) replies from users u left join contacts c on c.assigned=u.id group by u.id",d)})});
app.get('/api/orders',(q,r)=>r.json(all('select * from orders order by id desc limit 100')));
// ---- Catalogue & assignment
app.get('/api/products',(q,r)=>r.json(all('select * from products')));
app.post('/api/products',(q,r)=>{run('insert into products(name,price,descr) values(?,?,?)',q.body.name,q.body.price,q.body.descr);r.json({ok:1})});
app.delete('/api/products/:id',(q,r)=>{run('delete from products where id=?',q.params.id);r.json({ok:1})});
app.post('/api/contacts/:id/assign',async(q,r)=>{const c=get('select * from contacts where id=?',q.params.id);if(!c)return r.sendStatus(404);
if(c.assigned&&c.assigned!==q.user.id&&q.user.role!=='admin')return r.status(403).json({error:'A teammate is already handling this chat. Only an administrator can reassign it.'});
const to=q.body.to?+q.body.to:q.body.take?q.user.id:null;if(q.user.role!=='admin'&&to&&to!==q.user.id)return r.status(403).json({error:'You can only claim a conversation for yourself.'});if(to&&!get('select 1 x from users where id=?',to))return r.status(400).json({error:'Unknown teammate'});
const changed=db.transaction(()=>{const now=get('select assigned from contacts where id=?',c.id);if(now?.assigned&&now.assigned!==q.user.id&&q.user.role!=='admin')return false;run('update contacts set assigned=?,bot=0 where id=?',to,c.id);return true}).immediate();
if(!changed)return r.status(409).json({error:'Another teammate claimed this conversation. Refresh and try again.'});
if(to&&to!==q.user.id){enqueuePush([to],{kind:'assign',title:(c.name||'+'+c.phone).slice(0,60),body:q.user.name+' assigned you this chat',tag:'chat-'+c.id,cid:c.id,url:'/?chat='+c.id});const u=get('select * from users where id=?',to),last=get("select body from messages where contact_id=? and dir='in' order by id desc limit 1",c.id);if(u.phone)await alertUser(u,c,last?.body||'(no message yet)',q.user.name+' assigned you this chat. ')}
r.json({ok:1})});
// ---- Automations
app.get('/api/automations',(q,r)=>r.json(all('select * from automations')));
app.post('/api/automations',(q,r)=>{run('insert into automations(keyword,reply) values(?,?)',q.body.keyword,q.body.reply);r.json({ok:1})});
app.delete('/api/automations/:id',(q,r)=>{run('delete from automations where id=?',q.params.id);r.json({ok:1})});

// ---- Campaigns: opted-in contacts only, throttled, daily cap, auto-pause on failures
app.get('/api/campaigns',(q,r)=>r.json(all("select c.*,(select count(*) from messages m where m.body='[template] '||c.template and m.ts>=c.created and m.status in('delivered','read')) delivered,(select count(*) from messages m where m.body='[template] '||c.template and m.ts>=c.created and m.status='read') reads from campaigns c order by c.id desc")));
app.post('/api/campaigns',(q,r)=>{const{name,template,lang,label,vars,start}=q.body;
const rows=all('select id,labels from contacts where opted_in=1 and opted_out=0').filter(c=>!label||c.labels.split(',').map(s=>s.trim()).includes(label));
const id=run('insert into campaigns(name,template,lang,total,created,vars,start_at) values(?,?,?,?,?,?,?)',name,template,lang||'en',rows.length,Date.now(),vars||'',+start||0).lastInsertRowid;
db.transaction(()=>rows.forEach(c=>run('insert into queue(campaign_id,contact_id) values(?,?)',id,c.id)))();r.json({id,total:rows.length})});
app.post('/api/campaigns/:id/:act',(q,r)=>{run("update campaigns set status=? where id=? and status!='done'",q.params.act==='pause'?'paused':'running',q.params.id);r.json({ok:1})});
let busy=0;setInterval(async()=>{if(busy)return;busy=1;try{for(const b of M.prepare('select id from businesses').all())await als.run({db:open(b.id)},tick)}finally{busy=0}},+E.SEND_GAP_MS||1500);
async function tick(){const c=get("select * from campaigns where status='running' and start_at<=? order by id limit 1",Date.now());if(!c)return;
if(get("select count(*) n from messages where dir='out' and body like '[template]%' and ts>?",Date.now()-864e5).n>=(+E.DAILY_LIMIT||250))return;
const j=get('select q.id qid,ct.id cid,ct.phone,ct.name,ct.attrs,ct.opted_in,ct.opted_out from queue q join contacts ct on ct.id=q.contact_id where q.campaign_id=? and q.done=0 limit 1',c.id);
if(!j)return run("update campaigns set status='done' where id=?",c.id);
run('update queue set done=1 where id=?',j.qid);if(!j.opted_in||j.opted_out)return;
const vs=(c.vars||'').split(',').map(s=>s.trim()).filter(Boolean),tpl={name:c.template,language:{code:c.lang}};
if(vs.length)tpl.components=[{type:'body',parameters:vs.map(v=>({type:'text',text:v==='name'?(j.name||'there'):(JSON.parse(j.attrs||'{}')[v]??v)}))}];
try{const id=await wa({to:j.phone,type:'template',template:tpl});log(j.cid,'out','[template] '+c.template,id);run('update campaigns set sent=sent+1 where id=?',c.id)}
catch(e){run('update campaigns set failed=failed+1 where id=?',c.id);const x=get('select sent,failed from campaigns where id=?',c.id);if(x.failed>=5&&x.failed/(x.sent+x.failed)>0.1)run("update campaigns set status='paused' where id=?",c.id)}}
// ---- Customer media (voice notes, photos, video, documents). Meta's links expire in minutes, so we download and keep our own copy.
const fsx=require('fs'),path=require('path'),{execFile}=require('child_process');
const EXT={'audio/ogg':'ogg','audio/mpeg':'mp3','audio/mp4':'m4a','audio/aac':'aac','audio/amr':'amr','image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','video/mp4':'mp4','video/3gpp':'3gp','application/pdf':'pdf'},MAXMEDIA=25*1048576;
// Safari/iPhone cannot play WhatsApp's ogg/opus; if ffmpeg is installed we also keep an m4a copy.
const transcode=(src,dst)=>new Promise(res=>execFile('ffmpeg',['-y','-loglevel','error','-i',src,'-c:a','aac','-b:a','64k',dst],{timeout:30000},e=>res(e?null:dst)));
async function mediaTick(){if(!cfg('WA_TOKEN'))return;
for(const row of all('select id,media from messages where media_state=1 order by id limit 3')){let m;try{m=JSON.parse(row.media)}catch{run('update messages set media_state=3 where id=?',row.id);continue}if(Date.now()<(m.at||0))continue;
 try{const h={Authorization:'Bearer '+cfg('WA_TOKEN')},r1=await fetch('https://graph.facebook.com/v21.0/'+encodeURIComponent(m.id),{headers:h,signal:AbortSignal.timeout(20000)}),j=await r1.json().catch(()=>({}));
  const perm=m=>Object.assign(new Error(m),{perm:true});if(!r1.ok)throw r1.status===400||r1.status===404?perm(j.error?.message||'Media not found'):new Error(j.error?.message||'Meta '+r1.status);
  if(!/^https:\/\//.test(j.url||'')||j.file_size>MAXMEDIA)throw perm('Unusable media link');
  const r2=await fetch(j.url,{headers:h,signal:AbortSignal.timeout(60000)});if(!r2.ok)throw new Error('Download '+r2.status);const buf=Buffer.from(await r2.arrayBuffer());if(buf.length>MAXMEDIA)throw perm('Media too large');
  const mime=String(j.mime_type||m.mime||'').split(';')[0].trim().toLowerCase(),dir=path.join('media',String(als.getStore().bid)),safe=m.id.replace(/[^\w-]/g,''),file=path.join(dir,safe+'.'+(EXT[mime]||'bin'));
  fsx.mkdirSync(dir,{recursive:true});fsx.writeFileSync(file,buf);const alt=mime==='audio/ogg'?await transcode(file,path.join(dir,safe+'.m4a')):null;
  run('update messages set media=?,media_state=2 where id=?',JSON.stringify({...m,mime,file,alt}),row.id)}
 catch(e){const tries=(m.tries||0)+1;console.error('Media download failed:',e.message);run('update messages set media=?,media_state=? where id=?',JSON.stringify({...m,tries,at:Date.now()+Math.min(2**tries*1e4,18e5)}),e.perm||tries>=8?3:1,row.id)}}}
app.get('/api/media/:id',(q,r)=>{const row=get('select media,media_state from messages where id=?',q.params.id);let m;try{m=JSON.parse(row?.media||'')}catch{}
if(!m||row.media_state!==2)return r.sendStatus(404);const f=q.query.alt&&m.alt?m.alt:m.file,abs=f&&path.resolve(f);if(!abs||!abs.startsWith(path.resolve('media')+path.sep)||!fsx.existsSync(abs))return r.sendStatus(404);
r.setHeader('X-Content-Type-Options','nosniff');r.setHeader('Cache-Control','private, max-age=86400');if(!/^(audio|image|video)\//.test(m.mime))r.setHeader('Content-Disposition','attachment; filename="'+String(m.name||'file').replace(/[^\w.\- ]/g,'_')+'"');r.sendFile(abs)});
// ---- Background worker (every second): deliver push jobs, replay unprocessed webhook events, tidy old rows
let pbusy=0,ticks=0;setInterval(async()=>{if(pbusy)return;pbusy=1;ticks++;try{for(const b of M.prepare('select id from businesses').all())await als.run({db:open(b.id),bid:b.id},async()=>{
 await pushTick();await mediaTick();
 if(ticks%30===1)for(const e of all('select id from wh_events where done=0 and attempts<8 and created<? order by id limit 50',Date.now()-(ticks===1?0:2e4)))await processEvent(e.id);
 if(ticks%3600===2){run('delete from push_jobs where done=1 and created<?',Date.now()-864e5);run('delete from wh_events where done=1 and created<?',Date.now()-12096e5)}})}catch(e){console.error('Worker error:',e.message)}finally{pbusy=0}},1000);
app.listen(E.PORT||3000,()=>console.log('Running on :'+(E.PORT||3000)));
