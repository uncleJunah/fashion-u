// Web Push with no dependencies: VAPID (RFC 8292), payload encryption aes128gcm (RFC 8291), delivery (RFC 8030).
const crypto = require('crypto');

const b64u = b => Buffer.from(b).toString('base64url');
const unb64u = s => Buffer.from(String(s), 'base64url');

// A fresh VAPID key pair. publicKey is the 65-byte uncompressed point (base64url), privateKey is the raw scalar (base64url).
function generateVapid() {
  const { privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const j = privateKey.export({ format: 'jwk' });
  return { publicKey: b64u(Buffer.concat([Buffer.from([4]), unb64u(j.x), unb64u(j.y)])), privateKey: j.d };
}

function vapidKeyObject(vapid) {
  const pub = unb64u(vapid.publicKey);
  return crypto.createPrivateKey({ key: { kty: 'EC', crv: 'P-256', x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)), d: vapid.privateKey }, format: 'jwk' });
}

function vapidHeader(endpoint, vapid, subject) {
  const seg = o => b64u(JSON.stringify(o));
  const data = seg({ typ: 'JWT', alg: 'ES256' }) + '.' + seg({ aud: new URL(endpoint).origin, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject });
  const sig = crypto.sign('sha256', Buffer.from(data), { key: vapidKeyObject(vapid), dsaEncoding: 'ieee-p1363' });
  return 'vapid t=' + data + '.' + b64u(sig) + ', k=' + vapid.publicKey;
}

// RFC 8291 encryption for one record. `opts` (ephemeral key and salt) exists only so the RFC test vector can be reproduced.
function encrypt(plaintext, p256dh, auth, opts = {}) {
  const uaPublic = unb64u(p256dh), authSecret = unb64u(auth);
  if (uaPublic.length !== 65 || uaPublic[0] !== 4) throw new Error('Bad subscription key');
  if (authSecret.length !== 16) throw new Error('Bad subscription auth secret');
  const ecdh = crypto.createECDH('prime256v1');
  if (opts.asPrivate) ecdh.setPrivateKey(unb64u(opts.asPrivate)); else ecdh.generateKeys();
  const asPublic = ecdh.getPublicKey(), salt = opts.salt ? unb64u(opts.salt) : crypto.randomBytes(16);
  const secret = ecdh.computeSecret(uaPublic);
  const ikm = Buffer.from(crypto.hkdfSync('sha256', secret, authSecret, Buffer.concat([Buffer.from('WebPush: info\0'), uaPublic, asPublic]), 32));
  const cek = Buffer.from(crypto.hkdfSync('sha256', ikm, salt, 'Content-Encoding: aes128gcm\0', 16));
  const nonce = Buffer.from(crypto.hkdfSync('sha256', ikm, salt, 'Content-Encoding: nonce\0', 12));
  const body = Buffer.isBuffer(plaintext) ? plaintext : Buffer.from(plaintext);
  if (body.length > 3993) throw new Error('Payload too large');
  const c = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const enc = Buffer.concat([c.update(Buffer.concat([body, Buffer.from([2])])), c.final(), c.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPublic.length]), asPublic, enc]);
}

// Hosts of the browser push services. Subscriptions are supplied by logged-in users, so only these may be contacted.
const DEFAULT_HOSTS = ['googleapis.com', 'mozilla.com', 'apple.com', 'windows.com', 'microsoft.com'];
function endpointAllowed(endpoint, extra = []) {
  try {
    const u = new URL(endpoint);
    if (u.protocol !== 'https:' || (u.port && u.port !== '443')) return false;
    return [...DEFAULT_HOSTS, ...extra].some(h => u.hostname === h || u.hostname.endsWith('.' + h));
  } catch { return false }
}

// Returns {status}. 201/2xx = accepted, 404/410 = subscription is gone, 0 = network error, anything else = push service refused.
async function send(sub, payload, { vapid, subject, ttl = 86400, urgency = 'high' }) {
  const body = encrypt(payload, sub.p256dh, sub.auth);
  try {
    const r = await fetch(sub.endpoint, {
      method: 'POST',
      headers: { 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', TTL: String(ttl), Urgency: urgency, Authorization: vapidHeader(sub.endpoint, vapid, subject) },
      body, signal: AbortSignal.timeout(10000)
    });
    return { status: r.status };
  } catch (e) { return { status: 0, error: e.message } }
}

module.exports = { generateVapid, vapidHeader, encrypt, send, endpointAllowed, b64u, unb64u };
