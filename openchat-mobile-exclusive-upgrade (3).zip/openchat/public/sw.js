// OpenChat service worker: receives Web Push while the app is closed and shows the notification.
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

self.addEventListener('push', e => {
  let d = {};
  try { d = e.data ? e.data.json() : {} } catch { d = { body: e.data ? e.data.text() : '' } }
  const vibrate = d.vib === 0 ? [] : d.kind === 'order' ? [250, 100, 250, 100, 250] : [200, 100, 200];
  // Browsers (Safari especially) require every push to show a notification, so we always do. The tag makes
  // a chat's newest message replace its older one instead of stacking.
  e.waitUntil(self.registration.showNotification(d.title || 'OpenChat', {
    body: d.body || 'You have a new update',
    icon: '/icon-192.png', badge: '/icon-192.png',
    tag: d.tag || 'openchat-update', renotify: true, silent: false, vibrate,
    data: { url: d.url || '/', cid: d.cid || 0 }
  }));
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const { url = '/', cid = 0 } = e.notification.data || {};
  e.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    const w = list.find(c => 'focus' in c);
    if (w) { w.postMessage({ type: 'open', cid, url }); return w.focus() }
    return clients.openWindow(url);
  }));
});

// The browser rotated or dropped our subscription: get a new one and tell the server (works if the user is still signed in).
const toKey = b => Uint8Array.from(atob(b.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
self.addEventListener('pushsubscriptionchange', e => e.waitUntil((async () => {
  try {
    const { key } = await (await fetch('/api/push/key', { credentials: 'same-origin' })).json();
    const sub = await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: toKey(key) });
    await fetch('/api/push/subscribe', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ subscription: sub.toJSON() }) });
  } catch { /* the app re-registers itself the next time it opens */ }
})()));
