// Run: node test/push.test.js
const assert = require('assert'), crypto = require('crypto'), P = require('../push');

// 1) RFC 8291 section 5 / appendix A test vector (fixed keys and salt must give the exact published body)
const body = P.encrypt('When I grow up, I want to be a watermelon',
  'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4',
  'BTBZMqHH6r4Tts7J_aSIgg',
  { asPrivate: 'yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw', salt: 'DGv6ra1nlYgDCS1FRnbzlw' });
assert.strictEqual(P.b64u(body), 'DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN');
console.log('ok  RFC 8291 test vector');

// 2) Round trip: a fake browser decrypts what we send
const ua = crypto.createECDH('prime256v1'); ua.generateKeys();
const auth = crypto.randomBytes(16), msg = JSON.stringify({ title: 'Grace', body: 'Hello 👋' });
const enc = P.encrypt(msg, P.b64u(ua.getPublicKey()), P.b64u(auth));
const salt = enc.subarray(0, 16), idlen = enc[20], asPub = enc.subarray(21, 21 + idlen), ct = enc.subarray(21 + idlen);
const ikm = Buffer.from(crypto.hkdfSync('sha256', ua.computeSecret(asPub), auth, Buffer.concat([Buffer.from('WebPush: info\0'), ua.getPublicKey(), asPub]), 32));
const d = crypto.createDecipheriv('aes-128-gcm', Buffer.from(crypto.hkdfSync('sha256', ikm, salt, 'Content-Encoding: aes128gcm\0', 16)), Buffer.from(crypto.hkdfSync('sha256', ikm, salt, 'Content-Encoding: nonce\0', 12)));
d.setAuthTag(ct.subarray(ct.length - 16));
const plain = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
assert.strictEqual(plain.subarray(0, plain.length - 1).toString(), msg); assert.strictEqual(plain[plain.length - 1], 2);
console.log('ok  encrypt/decrypt round trip');

// 3) VAPID header carries a valid ES256 signature for the endpoint's origin
const v = P.generateVapid(), h = P.vapidHeader('https://fcm.googleapis.com/fcm/send/abc', v, 'mailto:you@example.com');
const [, t, k] = h.match(/^vapid t=([^,]+), k=(.+)$/); assert.strictEqual(k, v.publicKey);
const [a, b, s] = t.split('.'), pub = P.unb64u(v.publicKey);
const key = crypto.createPublicKey({ key: { kty: 'EC', crv: 'P-256', x: P.b64u(pub.subarray(1, 33)), y: P.b64u(pub.subarray(33)) }, format: 'jwk' });
assert(crypto.verify('sha256', Buffer.from(a + '.' + b), { key, dsaEncoding: 'ieee-p1363' }, P.unb64u(s)));
assert.strictEqual(JSON.parse(P.unb64u(b)).aud, 'https://fcm.googleapis.com');
console.log('ok  VAPID signature');

// 4) Only real browser push services are contacted
for (const [u, want] of [['https://fcm.googleapis.com/fcm/send/x', true], ['https://updates.push.services.mozilla.com/wpush/v2/x', true], ['https://web.push.apple.com/x', true], ['https://wns2-par02p.notify.windows.com/?token=x', true],
  ['http://fcm.googleapis.com/x', false], ['https://localhost/x', false], ['https://169.254.169.254/x', false], ['https://evilgoogleapis.com/x', false], ['https://fcm.googleapis.com:8443/x', false]])
  assert.strictEqual(P.endpointAllowed(u), want, u);
console.log('ok  endpoint allow-list');
