# OpenChat: self-hosted WhatsApp team inbox

Shared inbox, unlimited teammates, consent-only campaigns with variables, keyword automations, catalogue, public opt-in form, chat assignment, CSV upload and optional Claude AI replies. Uses the **official WhatsApp Cloud API**, which is what keeps numbers safe.

## 1. Meta setup (one time)
1. Create a Meta developer app, add WhatsApp, verify your business in Business Manager.
2. Put the Phone Number ID, a permanent System User token and the App Secret in `.env` (copy `.env.example`).
3. Webhook: callback `https://chat.yourdomain.com/webhook`, verify token = `VERIFY_TOKEN`, subscribe to **messages**.
4. Create templates in Meta and get them approved. For variables use `{{1}}`; in Campaigns type the values in order, e.g. `name, 20% off` (`name` is replaced with each contact's name).

## 2. Hosting for free: pick one
**Do not use Render's free tier.** It sleeps after 15 minutes (WhatsApp messages and queued campaigns stall) and wipes local files, including this app's database, on every restart.

**A. Your own always-on computer + Cloudflare Tunnel (free).** Works behind home internet, with free HTTPS.
1. Install Node 20.6+. Unzip `openchat.zip`, then: `cd openchat && npm install && cp .env.example .env` and fill in `.env`.
2. Run it permanently: `npm i -g pm2 && pm2 start server.js --name openchat --node-args="--env-file=.env" && pm2 save` (then `pm2 startup`).
3. Add your domain to a free Cloudflare account and change the nameservers at GoDaddy to the two Cloudflare gives you.
4. Install `cloudflared`, create a tunnel, and route `chat.yourdomain.com` to `http://localhost:3000` (Cloudflare Zero Trust, Networks, Tunnels shows the exact commands).

**B. A small VPS (about $5/month, or a free-forever VM if your provider offers one).** Upload with `scp openchat.zip root@SERVER_IP:~`, SSH in, then follow steps 1 and 2 above. In GoDaddy DNS add an **A record**: host `chat` → server IP. Install Caddy for automatic HTTPS: a Caddyfile with `chat.yourdomain.com { reverse_proxy localhost:3000 }`.

Open the site and sign in: the first account becomes the admin. **Back up `data.db` regularly.**

## 3. Safety built in
- Campaigns reach **only opted-in contacts**; consent is re-checked at send time.
- STOP/UNSUBSCRIBE opts out instantly; START opts back in.
- Throttled sending (`SEND_GAP_MS`), rolling 24h cap (`DAILY_LIMIT`, default 250), auto-pause if more than 10% of sends fail.
- Free-form replies are blocked after the 24-hour window.
- `/join` is your public opt-in page (share the link on your site or social). It doesn't verify the number, so ask new subscribers to reply START on WhatsApp as proof.

Also: relevant content only, raise volume slowly, watch your quality rating in Meta Business Manager, never buy lists, never use unofficial WhatsApp libraries.

## Not included
Sending media (customers can send voice notes, photos, video and documents, see below), visual flow builder, label editing screen.

## Credentials you must add (`.env`)
Required: `WA_PHONE_ID`, `WA_TOKEN`, `APP_SECRET`, `VERIFY_TOKEN` (Meta WhatsApp Cloud API). Optional: `ANTHROPIC_API_KEY` for AI replies. Nothing else. The **Setup** tab shows what's connected and sends a test message.

## Update: no file editing for credentials
Admins paste the Meta and Anthropic values into the **Setup** tab; they're stored on your server (values in `.env` still work as a fallback). Teammates join through **Team, Create invite link** (one-time, valid 7 days). Phones can install the site via "Add to Home Screen".

## Team on WhatsApp
Each teammate saves their WhatsApp number (Setup tab, or on the invite page). Every customer message is relayed to the number of every teammate; the **first one to read it or reply to it** (long-press, Reply) takes the chat, and later messages go only to them. Opening the chat on the website also takes it. Admins can release or reassign. The customer only ever sees your business number.
Rules from Meta: free-text alerts work if the teammate messaged the business number in the last 24 hours. Otherwise create a **utility template** with two variables, e.g. `New WhatsApp message from {{1}}: {{2}}. Reply to this message to answer.`, get it approved, and enter its name in Setup.

## New and old customers
Any number that messages you is saved automatically and alerts the team. Old customers can be added by CSV on the Contacts tab; set the default country code in Setup so numbers like `0700...` match the number WhatsApp reports. Old WhatsApp chat history can't be imported (Meta's API doesn't provide it). Duplicate webhook deliveries are ignored.

## Assigning chats
In the Inbox, use **Assign to…** to give a chat to any teammate (or back to Unassigned). The new owner gets it on their WhatsApp ("Name assigned you this chat…"); they reply to that message to answer. The person handling a chat, or an admin, can reassign it.

## Many businesses on one site
Anyone can register at `/register.html`; each business gets its own private database file in `biz/`, its own team, contacts, WhatsApp credentials (Setup tab) and links. **Webhook URL per business:** `https://your-domain/webhook/<business key>` (shown in Setup), so each business pastes its own into Meta. Credentials are no longer read from `.env`; only `SESSION_SECRET`, `PORT` and `NODE_ENV` are. Back up the whole `biz/` folder and `master.db`.
Note: opening registration to the public means anyone can create an account. Add your own limits if you don't want that.

## Online shop orders
In Setup, copy the **Store orders webhook**. Shopify: Settings, Notifications, Webhooks, create "Order creation" (JSON). WooCommerce: Settings, Advanced, Webhooks, "Order created". Any other site can POST JSON like `{"order_id":"1042","total":"120000","currency":"UGX","customer_name":"Grace","customer_phone":"256700111222","items":[{"name":"Rice","qty":2}]}`. Set the same secret in the shop and in Setup to verify requests. Each order alerts the team on WhatsApp and shows in the Orders tab.

## Inbox layout and extra tools
Left sidebar (Inbox, Contacts, Broadcasts, Automations, Catalogue, Orders, Dashboard, Setup, Team). Inbox has Open/Mine/Unassigned/Solved views, a contact panel (name, tags, attributes), internal notes, quick replies, and Mark solved. Broadcasts can be scheduled and show delivered/read counts. Attributes can be used as template variables. Welcome and away messages are in Automations.

## API keys at registration
The register page asks for the Meta Phone Number ID, access token, app secret and verify token (and an optional Anthropic key). The Phone Number ID and token are checked against Meta before the account is created. After registering, the page shows the business's webhook URL and verify token to paste into Meta. Everything can still be changed later in Setup.

## Free alerts (default)
Teammate alerts default to **Website only**: new chats and shop orders show as a badge, a sound and a browser notification while the site is open (installed or in a tab). No WhatsApp messages are sent to teammates, so there is no Meta charge for alerts. Choose "Also send to teammates' WhatsApp" in Setup to use the phone relay instead. Browser alerts need the page open; a phone may pause a background tab.


## Mobile inbox, vibration and exclusive conversation ownership

The inbox layout is responsive on narrow phone screens: conversations open as a focused chat view with a Back control, touch-friendly controls and a sticky composer. The desktop three-panel layout remains available on wider screens.

When OpenChat is open, the browser checks for new messages and orders. On supported Android browsers, the app can vibrate for those events. Vibration is enabled by default and can be switched off from the top bar. Browser vibration is not available on every device/browser; iOS web apps in particular may ignore the Vibration API. Browser notification permission is separate from vibration permission.

Conversation ownership is enforced on the server using the existing `contacts.assigned` field. Opening an unassigned conversation claims it for the first employee; sending a reply atomically claims an unassigned conversation before sending. Other employees can read the thread but their reply composer and template action are locked, and API requests from them are rejected. A non-admin can only claim a conversation for themselves. Administrators can reassign a conversation from the Inbox assignment control; the new owner can then reply. The same ownership check applies to replies received through the teammate WhatsApp relay.

## Background notifications, multi-employee alerts and reliable storage

**Turn alerts on once per device.** Each employee opens OpenChat, taps **🔔 Alerts** in the top bar (or Setup, Background alerts) and allows notifications. After that the phone or computer gets a notification, vibration and sound for new customer messages, assigned chats and orders, even when OpenChat is closed. **Send test alert** in Setup checks it. Signing out stops alerts on that device; signing in again restores them. The Team tab shows how many devices each person has set up.

**Who is alerted.** A new chat alerts every teammate until someone takes it. Once owned, only the owner is alerted, plus administrators (Setup can switch administrators off, and can hide the message text on lock screens). Assigning a chat alerts the new owner.

**Ownership.** The first employee to open or reply takes an unassigned chat. Everyone else is blocked by the server from replying, sending templates, or solving/reopening it, until an administrator reassigns it (or the owner releases it). Removing a teammate releases their chats.

**Never lose messages.** Every verified WhatsApp webhook call is saved to disk *before* we answer 200, so a crash or restart can't drop it, and anything not fully processed is replayed automatically. Duplicates are ignored. The message, unread counter and alert jobs are saved in one transaction, and alerts that fail are retried for up to 24 hours. Chats show an unread count and the app icon shows a badge, so nothing is missed when someone opens the app later.

**Requirements and limits**
- Push needs **https** (a real domain, or localhost for testing). Keys are generated automatically and stored in `master.db`; **back it up**, because if it is lost every device must tap Alerts again. Set `VAPID_SUBJECT` in `.env` to a contact email, e.g. `mailto:you@yourdomain.com`.
- **iPhone/iPad:** alerts only work after Share, **Add to Home Screen**, then opening OpenChat from that icon (iOS 16.4+).
- Sound and vibration on a closed app come from the phone's own notification settings; websites can't choose a custom sound. The in-app vibration switch is also respected by background alerts. Android supports vibration; iOS ignores it.
- **Hosting for 24/7 reception.** GitHub Codespaces is for testing only: it stops when idle. Production needs an always-running Node server (VPS, or your own computer with Cloudflare Tunnel, see section 2) with a public https webhook URL. Ordinary GoDaddy shared/WordPress hosting generally can't keep this app running; use a VPS (GoDaddy's or any other) or point your domain's DNS at one. Keep it running with `pm2` and monitor `https://your-domain/healthz` with a free uptime checker. While the server is down Meta retries webhooks for a limited time, but don't rely on that.
- Tests: `npm test` checks the push encryption against the official RFC 8291 test vector.

## Voice notes and customer media
Voice notes, photos, videos and documents that customers send now appear in the chat: voice notes get a play button, photos open full size, videos play in the chat, documents download. OpenChat downloads each file from Meta as soon as it arrives (Meta's links expire within minutes) and keeps its own copy in the `media/` folder, so **back up `media/` together with `biz/` and `master.db`**. The chat preview and alerts show "🎤 Voice note" or "📷 Photo". The AI auto-reply skips media messages. Limit 25 MB per file; failed downloads retry for a few hours.
WhatsApp voice notes are in Ogg/Opus, which iPhone Safari can't play. If **ffmpeg** is installed on the server (`apt install ffmpeg`), OpenChat automatically makes an iPhone-friendly copy; without it, voice notes still play on Android, Windows and Mac Chrome/Edge/Firefox and can always be downloaded.
Sending voice notes or media from OpenChat to customers is not included yet.
